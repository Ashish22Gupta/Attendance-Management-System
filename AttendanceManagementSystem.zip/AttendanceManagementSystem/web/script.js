document.addEventListener("DOMContentLoaded", function () {
    const menuBtn = document.querySelector(".menu-btn");
    const sidebar = document.querySelector(".sidebar");
    const mainContent = document.querySelector(".main-content");
    const menuItems = document.querySelectorAll(".sidebar ul li a");

    function checkScreenSize() {
        if (window.innerWidth >= 1200) {
            sidebar.classList.add("active");
            mainContent.classList.add("active");
        } else {
            sidebar.classList.remove("active");
            mainContent.classList.remove("active");
        }
    }

    menuBtn.addEventListener("click", function () {
        if (window.innerWidth < 1200) {
            sidebar.classList.toggle("active");
            mainContent.classList.toggle("active");
        }
    });

    menuItems.forEach(item => {
        item.addEventListener("click", function () {
            if (window.innerWidth < 1200) {
                sidebar.classList.remove("active");
                mainContent.classList.remove("active");
            }
        });
    });

    window.addEventListener("resize", checkScreenSize);
    checkScreenSize();
});

//for selected options js
//for Student Registeration
document.addEventListener('DOMContentLoaded', () => {
    const studentregistration = document.getElementById('student-registration');
    const contentContainer = document.getElementById('content-container');

    studentregistration.addEventListener('click', (e) => {
        e.preventDefault();
        fetch('register.html')
                .then(response => response.text())
                .then(html => {
                    contentContainer.innerHTML = html;
                })
                .catch(error => {
                    console.error('Error loading Profile page:', error);
                    contentContainer.innerHTML = '<p>Error loading profile.</p>';
                });
    });
});

////for updating the student records
document.addEventListener('DOMContentLoaded', () => {
    const studentDetailsLink = document.getElementById('student-details');
    const contentContainer = document.getElementById('content-container');

    // Load Student Management Page in an iframe
    studentDetailsLink.addEventListener('click', (e) => {
        e.preventDefault();
        loadStudentManagementPage();
    });

    function loadStudentManagementPage() {
        contentContainer.innerHTML = '';
        const iframe = document.createElement('iframe');
        iframe.src = 'StudentManagement.jsp';
        iframe.style.width = '100%';
        iframe.style.height = '90vh';
        iframe.style.border = 'none';
        iframe.style.borderRadius = '12px';

        contentContainer.appendChild(iframe);

        // Listen for messages from the iframe
        window.addEventListener('message', (event) => {
            if (event.data === 'backToMenu') {
                contentContainer.innerHTML = '';
                window.location.href = 'Panel.jsp';
            }
        });
    }
});

//for Searching student Details
document.addEventListener('DOMContentLoaded', () => {
    const searchDetailsLink = document.getElementById('searchdetails');
    const contentContainer = document.getElementById('content-container');

    searchDetailsLink.addEventListener('click', (e) => {
        e.preventDefault();
        fetch('search_details.jsp')
                .then(response => response.text())
                .then(html => {
                    contentContainer.innerHTML = html;
                    SearchEventListeners();
                })
                .catch(error => {
                    console.error('Error loading Student Management page:', error);
                    contentContainer.innerHTML = '<p>Error loading content.</p>';
                });
    });

    function SearchEventListeners() {
        const searchForm = contentContainer.querySelector('.detailSearch');
        if (searchForm) {
            searchForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(searchForm);
                fetch(`search_details.jsp?${new URLSearchParams(formData)}`)
                        .then(response => response.text())
                        .then(html => {
                            contentContainer.innerHTML = html;
                            const searchFormContainer = contentContainer.querySelector('#search-form-container');
                            const searchResultsContainer = contentContainer.querySelector('#search-results-container');
                            if (searchFormContainer)
                                searchFormContainer.style.display = 'none';
                            if (searchResultsContainer)
                                searchResultsContainer.style.display = 'block';
                            SearchEventListeners();
                        });
            });
        }
    }
});

//for Mark Attendance
document.addEventListener('DOMContentLoaded', () => {
    const markAttendanceLink = document.getElementById('Mark_attendance');
    const contentContainer = document.getElementById('content-container');
    markAttendanceLink.addEventListener('click', (e) => {
        e.preventDefault();
        loadAttendancePage();
    });

    function loadAttendancePage() {
        contentContainer.innerHTML = '';
        const iframe = document.createElement('iframe');
        iframe.src = 'attendance.jsp';
        iframe.style.width = '100%';
//        iframe.style.height = '90vh';
        iframe.style.border = 'none';

        contentContainer.appendChild(iframe);
        
        iframe.onload = () => {
            const iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
            iframe.style.height = iframeDocument.body.scrollHeight + 'px';
        };
    }
});

//for Profile Page
document.addEventListener('DOMContentLoaded', () => {
    const profileLink = document.querySelector('.Profile');
    const contentContainer = document.getElementById('content-container');

    profileLink.addEventListener('click', (e) => {
        e.preventDefault();
        fetch('Profile.jsp')
                .then(response => response.text())
                .then(html => {
                    contentContainer.innerHTML = html;
                })
                .catch(error => {
                    console.error('Error loading Profile page:', error);
                    contentContainer.innerHTML = '<p>Error loading profile.</p>';
                });
    });
});

//for update Attendance
document.addEventListener('DOMContentLoaded', () => {
    const updateAttendanceLink = document.getElementById('Update_attendance');
    const contentContainer = document.getElementById('content-container');

    updateAttendanceLink.addEventListener('click', (e) => {
        e.preventDefault();
        loadUpdateAttendancePage();
    });

    function loadUpdateAttendancePage() {
        contentContainer.innerHTML = '';
        const iframe = document.createElement('iframe');
        iframe.src = 'UpdateAttendance.jsp';
        iframe.style.width = '100%';
        iframe.style.border = 'none';
        iframe.style.borderRadius = '12px';

        contentContainer.appendChild(iframe);

        const adjustIframeHeight = () => {
            try {
                const iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
                iframe.style.height = iframeDocument.body.scrollHeight + 'px';
            } catch (e) {
                console.log('Error adjusting iframe height:', e);
            }
        };

        iframe.onload = adjustIframeHeight;

        const heightCheckInterval = setInterval(adjustIframeHeight, 500);

        iframe.addEventListener('load', () => {
            clearInterval(heightCheckInterval);
            const newInterval = setInterval(adjustIframeHeight, 500);
            iframe.contentWindow.addEventListener('unload', () => {
                clearInterval(newInterval);
            });
        });
    }
});

// View Attendance section
document.addEventListener('DOMContentLoaded', () => {
    const viewAttendanceLink = document.getElementById('view_attendance');
    const contentContainer = document.getElementById('content-container');

    viewAttendanceLink.addEventListener('click', (e) => {
        e.preventDefault();
        loadViewAttendancePage();
    });

    function loadViewAttendancePage() {
        contentContainer.innerHTML = '';
        const iframe = document.createElement('iframe');
        iframe.src = 'ViewAttendance.jsp';
        iframe.style.width = '100%';
        iframe.style.border = 'none';
        iframe.style.borderRadius = '12px';

        contentContainer.appendChild(iframe);

        const adjustIframeHeight = () => {
            try {
                const iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
                iframe.style.height = iframeDocument.body.scrollHeight + 'px';
            } catch (e) {
                console.log('Error adjusting iframe height:', e);
            }
        };

        iframe.onload = adjustIframeHeight;

        const heightCheckInterval = setInterval(adjustIframeHeight, 500);

        iframe.addEventListener('load', () => {
            clearInterval(heightCheckInterval);
            const newInterval = setInterval(adjustIframeHeight, 500);
            iframe.contentWindow.addEventListener('unload', () => {
                clearInterval(newInterval);
            });
        });
    }
});

//for Logout Page
document.addEventListener('DOMContentLoaded', () => {
    const logoutButton = document.querySelector('.sign-out');
    const contentContainer = document.getElementById('content-container');

    logoutButton.addEventListener('click', (e) => {
        e.preventDefault();
        fetch('logout.jsp')
                .then(response => response.text())
                .then(html => {
                    contentContainer.innerHTML = html;

                    const confirmLogoutBtn = contentContainer.querySelector('.logout-btn');
                    const cancelLogoutBtn = contentContainer.querySelector('.cancel-btn');

                    confirmLogoutBtn.addEventListener('click', () => {
                        window.location.href = 'logout';  
                    });

                    cancelLogoutBtn.addEventListener('click', () => {
                        window.location.href = 'Panel.jsp'; 
                    });
                })
                .catch(error => {
                    console.error('Error loading logout page:', error);
                    contentContainer.innerHTML = '<p>Error loading logout confirmation.</p>';
                });
    });
});