document.addEventListener("DOMContentLoaded", function () {
    const menuBtn = document.querySelector(".menu-btn");
    const sidebar = document.querySelector(".sidebar");
    const mainContent = document.querySelector(".main-content");
    const menuItems = document.querySelectorAll(".sidebar ul li a");

    function checkScreenSize() {
        if (window.innerWidth >= 1200) {
            sidebar.classList.add("active");
            mainContent.classList.add("active");
        } else {
            sidebar.classList.remove("active");
            mainContent.classList.remove("active");
        }
    }

    menuBtn.addEventListener("click", function () {
        if (window.innerWidth < 1200) {
            sidebar.classList.toggle("active");
            mainContent.classList.toggle("active");
        }
    });

    menuItems.forEach(item => {
        item.addEventListener("click", function () {
            if (window.innerWidth < 1200) {
                sidebar.classList.remove("active");
                mainContent.classList.remove("active");
            }
        });
    });

    window.addEventListener("resize", checkScreenSize);
    checkScreenSize();
});

document.addEventListener('DOMContentLoaded', () => {
    const studentRegLink = document.getElementById('student-registration');
    const contentContainer = document.getElementById('content-container');

    studentRegLink.addEventListener('click', (e) => {
        e.preventDefault();
        fetch('loadRegister')
            .then(response => response.text())
            .then(html => {
                contentContainer.innerHTML = html;
            })
            .catch(error => {
                console.error('Error loading the registration form:', error);
                contentContainer.innerHTML = '<p>Error loading content.</p>';
            });
    });
});
