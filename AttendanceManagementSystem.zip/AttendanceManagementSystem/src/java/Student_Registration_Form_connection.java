import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/register")
public class Student_Registration_Form_connection extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("name");
        String ageStr = request.getParameter("age");
        String contactStr = request.getParameter("contact");
        String course = request.getParameter("course");
        String doj = request.getParameter("doj");
        String branch = request.getParameter("branch");
        String gender = request.getParameter("gender");
        String dob = request.getParameter("dob");
        String Address = request.getParameter("address");
        String batch_time = request.getParameter("batch_time");

        try {
            int age = Integer.parseInt(ageStr);
            long contact = Long.parseLong(contactStr);

            java.sql.Date sqlDoj = null, sqlDob = null;
            if (doj != null && !doj.isEmpty()) {
                sqlDoj = java.sql.Date.valueOf(doj);
            }
            if (dob != null && !dob.isEmpty()) {
                sqlDob = java.sql.Date.valueOf(dob);
            }

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_management_system", "root", "");

            String sql = "INSERT INTO students (name, age, contact, course, doj, branch, gender, dob, address, batch_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setInt(2, age);
            ps.setLong(3, contact);
            ps.setString(4, course);
            ps.setDate(5, sqlDoj);
            ps.setString(6, branch);
            ps.setString(7, gender);
            ps.setDate(8, sqlDob);
            ps.setString(9, Address);
            ps.setString(10, batch_time);

            int rowsInserted = ps.executeUpdate();
            if (rowsInserted > 0) {
                response.sendRedirect("Panel.jsp");
            } else {
                out.println("<h3>Record Not Inserted</h3>");
            }

            ps.close();
            con.close();

        } catch (NumberFormatException e) {
            out.println("<h3>Error: Invalid number format for age or contact.</h3>");
        } catch (SQLException e) {
            out.println("<h3>Database Error: " + e.getMessage() + "</h3>");
        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}