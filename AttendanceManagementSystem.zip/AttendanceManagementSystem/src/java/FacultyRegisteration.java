import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/FacultyRegistration")
public class FacultyRegisteration extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String facultyCode = request.getParameter("facultyCode");
        String branch = request.getParameter("branch");
        String facultyName = request.getParameter("facultyName");
        String course = request.getParameter("course");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            // Load JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_management_system", "root", "");

            String query = "INSERT INTO faculty (faculty_code, branch, faculty_name, course, username, password) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, facultyCode);
            pstmt.setString(2, branch);
            pstmt.setString(3, facultyName);
            pstmt.setString(4, course);
            pstmt.setString(5, username);
            pstmt.setString(6, password);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                HttpSession session = request.getSession();
                session.setAttribute("facultyName", facultyName);
                session.setAttribute("facultyCourse", course);
                response.sendRedirect("Panel.jsp");
            } else {
                out.println("<h3>Error: Registration Failed!</h3>");
            }

            pstmt.close();
            con.close();
        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
